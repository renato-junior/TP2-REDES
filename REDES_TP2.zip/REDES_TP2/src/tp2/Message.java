package tp2;

/**
 *
 * @author renato
 */
public interface Message {

    public String getMessageJson();
    
}
